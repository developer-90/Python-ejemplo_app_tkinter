import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class ModificarPro:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Modificar Producto")

        # Crear y posicionar los elementos de la interfaz
        ttk.Label(ventana_padre, text="Nombre del Producto a Modificar:").grid(row=0, column=0, padx=10, pady=5)
        self.nombre_producto_entry = ttk.Entry(ventana_padre)
        self.nombre_producto_entry.grid(row=0, column=1, padx=10, pady=5)

        ttk.Button(ventana_padre, text="Buscar Producto", command=self.buscar_producto).grid(row=1, column=0, columnspan=2, pady=10)

        # Elementos para mostrar o modificar información del producto
        ttk.Label(ventana_padre, text="Nuevo Nombre:").grid(row=2, column=0, padx=10, pady=5)
        self.nuevo_nombre_entry = ttk.Entry(ventana_padre)
        self.nuevo_nombre_entry.grid(row=2, column=1, padx=10, pady=5)

        ttk.Label(ventana_padre, text="Nuevo Precio:").grid(row=3, column=0, padx=10, pady=5)
        self.nuevo_precio_entry = ttk.Entry(ventana_padre)
        self.nuevo_precio_entry.grid(row=3, column=1, padx=10, pady=5)

        ttk.Button(ventana_padre, text="Modificar Producto", command=self.modificar_producto).grid(row=4, column=0, columnspan=2, pady=10)

    def buscar_producto(self):
        nombre_producto = self.nombre_producto_entry.get()

        # Validar que se ingrese un nombre de producto válido
        if not nombre_producto:
            messagebox.showerror("Error", "Por favor, ingrese un nombre de producto.")
            return

        # Conectar a la base de datos y buscar el producto por nombre
        try:
            conexion = sqlite3.connect('database.db')
            cursor = conexion.cursor()

            cursor.execute("SELECT * FROM Producto WHERE nombre = ?", (nombre_producto,))
            producto = cursor.fetchone()

            conexion.close()

            if producto:
                # Llamar a una función para mostrar o modificar la información del producto en la interfaz
                self.mostrar_o_modificar_producto(producto)
            else:
                messagebox.showwarning("Advertencia", "No se encontró un producto con el nombre proporcionado.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al buscar el producto: {str(e)}")

    def mostrar_o_modificar_producto(self, producto):
        # Mostrar la información del producto en la interfaz
        self.nuevo_nombre_entry.delete(0, tk.END)
        self.nuevo_nombre_entry.insert(0, producto[1])  # asumiendo que el nombre del producto está en la segunda columna

        self.nuevo_precio_entry.delete(0, tk.END)
        self.nuevo_precio_entry.insert(0, producto[2])  # asumiendo que el precio del producto está en la tercera columna

        # Después de mostrar la información, puedes permitir al usuario modificarla si es necesario

    def modificar_producto(self):
        nuevo_nombre = self.nuevo_nombre_entry.get()
        nuevo_precio = self.nuevo_precio_entry.get()

        # Validar que se ingresen valores válidos
        if not nuevo_nombre or not nuevo_precio:
            messagebox.showerror("Error", "Por favor, ingrese un nuevo nombre y precio.")
            return

        # Conectar a la base de datos y ejecutar la sentencia SQL para modificar el producto
        try:
            conexion = sqlite3.connect('database.db')
            cursor = conexion.cursor()

            # Modificar el producto con el nuevo nombre y precio
            cursor.execute("UPDATE Producto SET nombre = ?, precio = ? WHERE nombre = ?",
                           (nuevo_nombre, nuevo_precio, self.nombre_producto_entry.get()))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Producto modificado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al modificar el producto: {str(e)}")

# Ejemplo de cómo usar la clase en tu aplicación principal
if __name__ == "__main__":
    root = tk.Tk()
    ventana_modificar_pro = tk.Toplevel(root)
    app = ModificarPro(ventana_modificar_pro)
    root.mainloop()
