import tkinter as tk  # Importar la biblioteca tkinter para la interfaz gráfica
from tkinter import ttk, messagebox  # Importar clases específicas de tkinter y messagebox para mensajes de ventana
import sqlite3  # Importar la biblioteca sqlite3 para trabajar con bases de datos SQLite

# Clase para ordenar los encabezados de un Treeview
class TreeviewHeaderSorter:
    def __init__(self, treeview):
        self.treeview = treeview
        self.treeview.heading_columns = {}

        # Configurar los encabezados del Treeview y asignar la función de ordenamiento
        for col in treeview["columns"]:
            self.treeview.heading_columns[col] = False
            treeview.heading(col, text=col, command=lambda c=col: self.sort_treeview(c, True))

    # Función para ordenar el Treeview por la columna especificada
    def sort_treeview(self, col, reverse):
        data = [(self.treeview.set(child, col), child) for child in self.treeview.get_children('')]
        data.sort(reverse=reverse)

        # Mover los elementos en el Treeview según el orden ordenado
        for index, item in enumerate(data):
            self.treeview.move(item[1], '', index)

        # Cambiar la dirección del ordenamiento y configurar el encabezado
        self.treeview.heading_columns[col] = not self.treeview.heading_columns[col]
        self.treeview.heading(col, text=col, command=lambda c=col: self.sort_treeview(c, not self.treeview.heading_columns[col]))

# Clase para mostrar productos en un Treeview
class Mostrar:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Mostrar Productos")  # Configurar el título de la ventana

        estilo = ttk.Style()

        # Configurar el estilo de la interfaz gráfica
        estilo.theme_use("clam")
        estilo.configure("Custom.Treeview", background='#E6F7FF', fieldbackground='#E6F7FF', foreground='#1C1C1C')
        estilo.map("Custom.Treeview", background=[('selected', '#0056b3')])

        # Crear el Treeview con columnas y estilos personalizados
        self.treeview = ttk.Treeview(
            ventana_padre,
            columns=('Nombre', 'Precio', 'Categoría', 'Cantidad', 'Precio/unidad'),
            show='headings',
            style='Custom.Treeview'
        )

        # Configurar los encabezados del Treeview
        self.treeview.heading('Nombre', text='Nombre')
        self.treeview.heading('Precio', text='Precio (€)')
        self.treeview.heading('Categoría', text='Categoría')
        self.treeview.heading('Cantidad', text='Cantidad')
        self.treeview.heading('Precio/unidad', text='Precio/unidad')

        # Configurar columnas del Treeview
        for col in ('Nombre', 'Precio', 'Categoría', 'Cantidad', 'Precio/unidad'):
            self.treeview.column(col, anchor='center')

        self.treeview.pack(fill='both', expand=True)  # Empaquetar el Treeview en la ventana

        # Botón para mostrar los productos en el Treeview
        ttk.Button(
            ventana_padre,
            text='Mostrar Productos',
            command=self.mostrar_datos,
            style='Custom.TButton'
        ).pack(pady=10)

        # Configurar el estilo de los encabezados y botones
        estilo.configure("Custom.Treeview.Heading", font=('TkDefaultFont', 11, 'bold'), background='#99c2ff')
        estilo.configure("Custom.TButton", padding=(10, 5), font=('TkDefaultFont', 11), background='#007BFF', foreground='#FFFFFF')

        # Inicializar el ordenador de encabezados
        TreeviewHeaderSorter(self.treeview)

    # Función para mostrar datos en el Treeview desde la base de datos
    def mostrar_datos(self):
        try:
            with sqlite3.connect('database.db') as conn:
                cursor = conn.cursor()
                self.limpiar_treeview()  # Limpiar los datos anteriores en el Treeview
                cursor.execute("SELECT p.nombre, p.precio || ' €', c.nombre, d.cantidad, d.precio_unitario "
                               "FROM Producto as p INNER JOIN Categoria as c ON p.id_categoria = c.id_categoria "
                               "INNER JOIN Detalle as d ON d.id_producto = p.id_producto")
                data = cursor.fetchall()
                for row in data:
                    self.treeview.insert('', 'end', values=row)  # Insertar datos en el Treeview
        except Exception as e:
            print(f"Error al mostrar datos: {str(e)}")
            messagebox.showerror("Error", f"No se pudo mostrar los datos: {str(e)}")

    # Función para limpiar el Treeview de datos anteriores
    def limpiar_treeview(self):
        for item in self.treeview.get_children():
            self.treeview.delete(item)

# Inicializar la aplicación
if __name__ == "__main__":
    root = tk.Tk()  # Crear la ventana principal
    ventana_mostrar = tk.Toplevel(root)  # Crear una ventana secundaria
    mostrar_app = Mostrar(ventana_mostrar)  # Crear una instancia de la clase Mostrar
    root.mainloop()  # Iniciar el bucle principal de tkinter
