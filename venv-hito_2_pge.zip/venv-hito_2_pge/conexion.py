import sqlite3

def crear_base_datos():
    # Conectar a la base de datos (se creará si no existe)
    conexion = sqlite3.connect('database.db')

    # Crear un cursor
    cursor = conexion.cursor()

    # Crear la tabla Cliente
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Cliente (
            id_cliente INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL,
            direccion TEXT,
            telefono TEXT
        )
    ''')

    # Crear la tabla Producto
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Producto (
            id_producto INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            id_categoria INTEGER,
            FOREIGN KEY (id_categoria) REFERENCES Categoria(id_categoria)
        )
    ''')

    # Crear la tabla Detalle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Detalle (
            id_detalle INTEGER PRIMARY KEY,
            id_pedido INTEGER,
            id_producto INTEGER,
            cantidad INTEGER,
            precio_unitario REAL,
            FOREIGN KEY (id_pedido) REFERENCES Pedido(id_pedido),
            FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
        )
    ''')

    # Crear la tabla Categoria
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Categoria (
            id_categoria INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL
        )
    ''')
    
    # Insertar categorías específicas (frutas, verduras, carne)
    cursor.executemany('''
    INSERT INTO Categoria (nombre) VALUES (?)
    ''', [('frutas',), ('verduras',), ('carnes',)])

    # Crear la tabla Pedido
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Pedido (
            id_pedido INTEGER PRIMARY KEY,
            fecha TEXT NOT NULL,
            id_cliente INTEGER,
            FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
        )
    ''')

    # Guardar los cambios y cerrar la conexión
    conexion.commit()
    conexion.close()

if __name__ == "__main__":
    crear_base_datos()