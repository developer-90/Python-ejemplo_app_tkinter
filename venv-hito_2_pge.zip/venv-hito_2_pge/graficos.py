import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class Graficos:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Mostrar Gráficos")

        # Crear y posicionar los elementos de la interfaz
        ttk.Button(ventana_padre, text="Frutas", command=self.mostrar_grafico_frutas).grid(row=0, column=0, padx=10, pady=10)
        ttk.Button(ventana_padre, text="Verduras", command=self.mostrar_grafico_verduras).grid(row=1, column=0, padx=10, pady=10)
        ttk.Button(ventana_padre, text="Carnes", command=self.mostrar_grafico_carnes).grid(row=2, column=0, padx=10, pady=10)

    def mostrar_grafico(self, datos, etiquetas_x, etiqueta_y, titulo):
        try:
            # Crear el gráfico
            fig, ax = plt.subplots()
            ax.bar(etiquetas_x, datos)
            ax.set_xlabel('Producto')
            ax.set_ylabel(etiqueta_y)
            ax.set_title(titulo)

            # Mostrar el gráfico en la interfaz usando FigureCanvasTkAgg
            canvas = FigureCanvasTkAgg(fig, master=self.ventana_padre)
            canvas_widget = canvas.get_tk_widget()
            canvas_widget.grid(row=3, column=0, padx=10, pady=10)

            # Dibujar el gráfico en el lienzo
            canvas.draw()

        except Exception as e:
            messagebox.showerror("Error", f"Error al mostrar el gráfico: {str(e)}")

    def obtener_datos_categoria(self, categoria):
        try:
            # Conectar a la base de datos y recuperar los datos para el gráfico
            conexion = sqlite3.connect('database.db')
            consulta_sql = f"""
                SELECT p.nombre, p.precio
                FROM Producto p
                JOIN Categoria c ON p.id_categoria = c.id_categoria
                WHERE c.nombre = ?;
            """
            resultado = conexion.execute(consulta_sql, (categoria.lower(),)).fetchall()
            conexion.close()

            # Preparar los datos para el gráfico
            productos = [fila[0] for fila in resultado]
            precios = [fila[1] for fila in resultado]

            return productos, precios

        except Exception as e:
            messagebox.showerror("Error", f"Error al obtener los datos: {str(e)}")

    def mostrar_grafico_frutas(self):
        productos, precios = self.obtener_datos_categoria("frutas")
        self.mostrar_grafico(precios, productos, 'Precio', 'Productos de la categoría Frutas')

    def mostrar_grafico_verduras(self):
        productos, precios = self.obtener_datos_categoria("verduras")
        self.mostrar_grafico(precios, productos, 'Precio', 'Productos de la categoría Verduras')

    def mostrar_grafico_carnes(self):
        productos, precios = self.obtener_datos_categoria("carnes")
        self.mostrar_grafico(precios, productos, 'Precio', 'Productos de la categoría Carnes')

# Ejemplo de cómo usar la clase en tu aplicación principal
if __name__ == "__main__":
    root = tk.Tk()
    ventana_graficos = tk.Toplevel(root)
    app = Graficos(ventana_graficos)
    root.mainloop()
