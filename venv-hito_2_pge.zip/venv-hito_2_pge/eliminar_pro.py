import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class EliminarPro:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Eliminar Producto")

        # Crear y posicionar los elementos de la interfaz
        ttk.Label(ventana_padre, text="Nombre del Producto a Eliminar:").grid(row=0, column=0, padx=10, pady=5)
        self.nombre_producto_entry = ttk.Entry(ventana_padre)
        self.nombre_producto_entry.grid(row=0, column=1, padx=10, pady=5)

        ttk.Button(ventana_padre, text="Buscar Producto", command=self.buscar_producto).grid(row=1, column=0, columnspan=2, pady=10)
        ttk.Button(ventana_padre, text="Eliminar Producto", command=self.eliminar_producto).grid(row=2, column=0, columnspan=2, pady=10)

    def buscar_producto(self):
        nombre_producto = self.nombre_producto_entry.get()

        # Validar que se ingrese un nombre de producto válido
        if not nombre_producto:
            messagebox.showerror("Error", "Por favor, ingrese un nombre de producto.")
            return

        # Conectar a la base de datos y buscar el producto por nombre
        try:
            conexion = sqlite3.connect('database.db')
            cursor = conexion.cursor()

            cursor.execute("SELECT * FROM Producto WHERE nombre = ?", (nombre_producto,))
            producto = cursor.fetchone()

            conexion.close()

            if producto:
                # Llamar a una función para mostrar la información del producto en la interfaz
                self.mostrar_informacion_producto(producto)
            else:
                messagebox.showwarning("Advertencia", "No se encontró un producto con el nombre proporcionado.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al buscar el producto: {str(e)}")

    def mostrar_informacion_producto(self, producto):
        # Mostrar la información del producto en la interfaz (puedes ajustar según tu diseño)
        mensaje = "Nombre: {}\nPrecio: {}".format(producto[1], producto[2])
        messagebox.showinfo("Información del Producto", mensaje)

    def eliminar_producto(self):
        nombre_producto = self.nombre_producto_entry.get()

        # Validar que se ingrese un nombre de producto válido
        if not nombre_producto:
            messagebox.showerror("Error", "Por favor, ingrese un nombre de producto.")
            return

        # Confirmar la eliminación del producto
        respuesta = messagebox.askyesno("Confirmar Eliminación", f"¿Estás seguro de eliminar el producto '{nombre_producto}'?")

        if respuesta:
            # Conectar a la base de datos y ejecutar la sentencia SQL para eliminar el producto
            try:
                conexion = sqlite3.connect('database.db')
                cursor = conexion.cursor()

                # Eliminar el producto por nombre
                cursor.execute("DELETE FROM Producto WHERE nombre = ?", (nombre_producto,))

                conexion.commit()
                conexion.close()

                messagebox.showinfo("Éxito", f"Producto '{nombre_producto}' eliminado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"Error al eliminar el producto: {str(e)}")

# Ejemplo de cómo usar la clase en tu aplicación principal
if __name__ == "__main__":
    root = tk.Tk()
    ventana_eliminar_pro = tk.Toplevel(root)
    app = EliminarPro(ventana_eliminar_pro)
    root.mainloop()
