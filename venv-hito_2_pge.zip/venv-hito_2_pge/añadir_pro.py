import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class AñadirPro:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Añadir Producto")

        # Crear y posicionar los elementos de la interfaz
        ttk.Label(ventana, text="Nombre del producto:").grid(row=0, column=0, padx=10, pady=5)
        self.nombre_entry = ttk.Entry(ventana)
        self.nombre_entry.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(ventana, text="Precio:").grid(row=1, column=0, padx=10, pady=5)
        self.precio_entry = ttk.Entry(ventana)
        self.precio_entry.grid(row=1, column=1, padx=10, pady=5)

        ttk.Label(ventana, text="Categoría:").grid(row=2, column=0, padx=10, pady=5)
        self.categoria_combobox = ttk.Combobox(ventana, values=["verduras", "frutas", "carnes"])
        self.categoria_combobox.grid(row=2, column=1, padx=10, pady=5)

        ttk.Label(ventana, text="Cantidad:").grid(row=3, column=0, padx=10, pady=5)
        self.cantidad_entry = ttk.Entry(ventana)
        self.cantidad_entry.grid(row=3, column=1, padx=10, pady=5)

        ttk.Label(ventana, text="Precio Unitario:").grid(row=4, column=0, padx=10, pady=5)
        self.precio_unitario_entry = ttk.Entry(ventana)
        self.precio_unitario_entry.grid(row=4, column=1, padx=10, pady=5)

        agregar_button = ttk.Button(ventana, text="Agregar producto", command=self.agregar_producto)
        agregar_button.grid(row=5, column=0, columnspan=2, pady=10)

    def agregar_producto(self):
        nombre = self.nombre_entry.get()
        precio = self.precio_entry.get()
        categoria = self.categoria_combobox.get()
        cantidad = self.cantidad_entry.get()
        precio_unitario = self.precio_unitario_entry.get()

        try:
            with sqlite3.connect('database.db') as conexion:
                cursor = conexion.cursor()

                if not categoria:
                    messagebox.showerror("Error", "Selecciona una categoría")
                    return
                
                # Buscar el ID de la categoría seleccionada en la base de datos
                cursor.execute("SELECT id_categoria FROM Categoria WHERE nombre=?", (categoria,))
                result = cursor.fetchone()

                if result:
                    id_categoria = result[0]
                else:
                    messagebox.showerror("Error", "La categoría no existe")
                    return

                # Iniciar una transacción
                with conexion:
                    # Insertar el nuevo producto en la tabla Producto
                    cursor.execute("INSERT INTO Producto (nombre, precio, id_categoria) VALUES (?, ?, ?)",
                                   (nombre, precio, id_categoria))

                    # Obtener el ID del último producto insertado
                    id_producto = cursor.lastrowid

                    # Insertar la información en la tabla Detalle
                    cursor.execute("INSERT INTO Detalle (id_producto, cantidad, precio_unitario) VALUES (?, ?, ?)",
                                   (id_producto, cantidad, precio_unitario))

            messagebox.showinfo("Éxito", "Producto agregado correctamente")

        except sqlite3.IntegrityError as e:
            messagebox.showerror("Error", f"Violación de integridad: {str(e)}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo agregar el producto: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()  # Crear la ventana principal
    añadir_pro = AñadirPro(root)  # Crear una instancia de la clase AñadirPro
    root.mainloop()  # Iniciar el bucle principal de tkinter
