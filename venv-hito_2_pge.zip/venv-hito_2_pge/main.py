# Importar las bibliotecas necesarias
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from añadir_pro import AñadirPro as ap
from añadir_cli import Añadir_cli as ac
from modificar_pro import ModificarPro as mp
from eliminar_pro import EliminarPro as ep
from exportar import Exportar as e
from graficos import Graficos as g
from mostrar import Mostrar as m
from conexion import crear_base_datos

# Definir la clase principal del módulo ERP
class ERPModule:
    def __init__(self, root):
        self.root = root
        self.root.title("ERP Module")
        
        # Crear la base de datos antes de usarla
        crear_base_datos()
        
        # Cargar la imagen y redimensionar
        image = "emoji.jpg"

        # Crear el frame principal
        main_frame = ttk.Frame(root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        original_image = Image.open(image)
        resized_image = original_image.resize((200, 200))
        self.logo_image = ImageTk.PhotoImage(resized_image)

        # Mostrar la imagen en la parte superior
        if self.logo_image:
            logo_label = ttk.Label(main_frame, image=self.logo_image)
            logo_label.grid(row=0, column=0, columnspan=3, pady=10)

        estilo = ttk.Style()
        # Crear estilo utilizado por defecto para todos los Frames
        estilo.configure('TFrame', background='white', relief='flat')
        
        # Botones en el frame principal
        ttk.Button(main_frame, text="Añadir Producto", command=self.añadir_pro).grid(row=1, column=0, padx=15, pady=15)
        ttk.Button(main_frame, text="Modificar Producto", command=self.modificar_pro).grid(row=1, column=1, padx=15, pady=15)
        ttk.Button(main_frame, text="Eliminar Producto", command=self.eliminar_pro).grid(row=1, column=2, padx=15, pady=15)
        ttk.Button(main_frame, text="Añadir Cliente", command=self.añadir_cli).grid(row=2, column=0, padx=15, pady=15)
        ttk.Button(main_frame, text="Mostrar Gráficos", command=self.graficos).grid(row=2, column=1, padx=15, pady=15)
        ttk.Button(main_frame, text="Exportar a Excel", command=self.exportar).grid(row=2, column=2, padx=15, pady=15)
        ttk.Button(main_frame, text="Mostrar Productos", command=self.mostrar_productos).grid(row=3, column=1, padx=15, pady=15)
        ttk.Button(main_frame, text="Salir", command=self.root.destroy, style="Exit.TButton").grid(row=4, column=0, columnspan=3, pady=50)
        
    def añadir_pro(self):
        # Ventana para añadir un nuevo producto
        ventanaAñadirPro = tk.Toplevel(self.root)
        ventanaAñadirPro.title("Añadir Producto")
        ap(ventanaAñadirPro)

    def modificar_pro(self):
        # Ventana para modificar un producto existente
        ventanaModificarPro = tk.Toplevel(self.root)
        ventanaModificarPro.title("Modificar Producto")
        mp(ventanaModificarPro)
        
    def eliminar_pro(self):
        # Ventana para eliminar un producto existente
        ventanaEliminarPro = tk.Toplevel(self.root)
        ventanaEliminarPro.title("Eliminar Producto")
        ep(ventanaEliminarPro)

    def añadir_cli(self):
        # Ventana para añadir un nuevo cliente
        ventanaAñadirCli = tk.Toplevel(self.root)
        ventanaAñadirCli.title("Añadir Cliente")
        ac(ventanaAñadirCli)

    def exportar(self):
        # Ventana para exportar datos a Excel
        ventanaExportar = tk.Toplevel(self.root)
        ventanaExportar.title("Exportar a Excel")
        e(ventanaExportar)

    def graficos(self):
        # Ventana para mostrar gráficos
        ventanaGraficos = tk.Toplevel(self.root)
        ventanaGraficos.title("Mostrar Gráficos")
        g(ventanaGraficos)
        
    def mostrar_productos(self):
        # Ventana para mostrar la lista de productos
        ventanaMostrar = tk.Toplevel(self.root)
        ventanaMostrar.title("Mostrar Productos")
        m(ventanaMostrar)

# Programa principal
if __name__ == "__main__":
    root = tk.Tk()
    app = ERPModule(root)
    root.mainloop()
