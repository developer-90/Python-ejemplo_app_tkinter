import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import pandas as pd

class Exportar:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Exportar a Excel")

        # Crear y posicionar los elementos de la interfaz
        ttk.Label(ventana_padre, text="Seleccionar tabla para exportar:").grid(row=0, column=0, padx=10, pady=5)

        # Variable de control para la lista desplegable
        self.tabla_seleccionada = tk.StringVar()
        self.tabla_seleccionada.set("Producto")  # Valor predeterminado

        # Lista desplegable con las tablas disponibles
        tablas_disponibles = ["Cliente", "Producto", "Detalle", "Categoria", "Pedido"]
        self.tabla_combobox = ttk.Combobox(ventana_padre, textvariable=self.tabla_seleccionada, values=tablas_disponibles)
        self.tabla_combobox.grid(row=0, column=1, padx=10, pady=5)

        ttk.Button(ventana_padre, text="Exportar a Excel", command=self.exportar_a_excel).grid(row=1, column=0, columnspan=2, pady=10)

    def exportar_a_excel(self):
        tabla_seleccionada = self.tabla_seleccionada.get()

        try:
            # Conectar a la base de datos y recuperar los datos de la tabla seleccionada
            conexion = sqlite3.connect('database.db')
            consulta_sql = f"SELECT * FROM {tabla_seleccionada}"
            df = pd.read_sql_query(consulta_sql, conexion)
            conexion.close()

            # Obtener la ruta de archivo para guardar el archivo Excel
            archivo_excel = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Archivos Excel", "*.xlsx")])

            if archivo_excel:
                # Exportar los datos al archivo Excel
                df.to_excel(archivo_excel, index=False)
                messagebox.showinfo("Éxito", f"Datos de la tabla '{tabla_seleccionada}' exportados a Excel correctamente.")
            else:
                messagebox.showwarning("Cancelado", "Exportación cancelada por el usuario.")
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Error al exportar a Excel: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    ventana_exportar = tk.Toplevel(root)
    app = Exportar(ventana_exportar)
    root.mainloop()
