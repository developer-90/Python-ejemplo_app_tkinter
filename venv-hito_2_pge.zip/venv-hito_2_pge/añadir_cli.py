import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class Añadir_cli:
    def __init__(self, ventana_padre):
        self.ventana_padre = ventana_padre
        self.ventana_padre.title("Añadir Cliente")

        # Crear y posicionar los elementos de la interfaz
        ttk.Label(ventana_padre, text="Nombre del Cliente:").grid(row=0, column=0, padx=10, pady=5)
        self.nombre_cliente_entry = ttk.Entry(ventana_padre)
        self.nombre_cliente_entry.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(ventana_padre, text="Dirección del Cliente:").grid(row=1, column=0, padx=10, pady=5)
        self.direccion_cliente_entry = ttk.Entry(ventana_padre)
        self.direccion_cliente_entry.grid(row=1, column=1, padx=10, pady=5)

        ttk.Label(ventana_padre, text="Teléfono del Cliente:").grid(row=2, column=0, padx=10, pady=5)
        self.telefono_cliente_entry = ttk.Entry(ventana_padre)
        self.telefono_cliente_entry.grid(row=2, column=1, padx=10, pady=5)

        ttk.Button(ventana_padre, text="Añadir Cliente", command=self.añadir_cliente).grid(row=3, column=0, columnspan=2, pady=10)

    def añadir_cliente(self):
        nombre_cliente = self.nombre_cliente_entry.get()
        direccion_cliente = self.direccion_cliente_entry.get()
        telefono_cliente = self.telefono_cliente_entry.get()

        # Validar que se ingresen valores válidos
        if not nombre_cliente:
            messagebox.showerror("Error", "Por favor, ingrese el nombre del cliente.")
            return

        # Conectar a la base de datos y ejecutar la sentencia SQL para agregar el cliente
        try:
            conexion = sqlite3.connect('database.db')
            cursor = conexion.cursor()

            # Insertar el nuevo cliente en la base de datos
            cursor.execute("INSERT INTO Cliente (nombre, direccion, telefono) VALUES (?, ?, ?)",
                           (nombre_cliente, direccion_cliente, telefono_cliente))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Cliente añadido correctamente.")
            self.ventana_padre.destroy()  # Cerrar la ventana después de añadir el cliente
        except Exception as e:
            messagebox.showerror("Error", f"Error al añadir el cliente: {str(e)}")

# Programa principal
if __name__ == "__main__":
    root = tk.Tk()
    ventana_añadir_cli = tk.Toplevel(root)
    app = Añadir_cli(ventana_añadir_cli)
    root.mainloop()
